package com.damasUniv.acApp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

//import at.lukle.clickableareasimage.OnClickableAreaClickedListener;

//import at.lukle.clickableareasimage.OnClickableAreaClickedListener;

public class gamtest extends AppCompatActivity  {
     ImageView currentimag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamtest);
      //  currentimag=(ImageView)findViewById(R.id.currImage);
       // currentimag.setBackgroundResource(R.drawable.chaircurr1);

    }



}
