package com.damasUniv.acApp;

public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://syad3.000webhostapp.com/autism-web/api/login.php";

}